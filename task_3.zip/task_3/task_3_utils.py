"""Modulo Task 3"""



if __name__ == "__main__":
    print("Modulo Task 3")